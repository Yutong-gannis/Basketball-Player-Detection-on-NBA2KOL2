#!/bin/bash

mkdir -p images

wget https://user-images.githubusercontent.com/4212806/180578035-e39cae5d-db18-4941-98a8-d697a1ba2336.jpg -O images/image_0.jpg
wget https://user-images.githubusercontent.com/4212806/180578037-98d81133-0e05-4bdf-ac2b-9918cacc8e64.jpg -O images/image_1.jpg
wget https://user-images.githubusercontent.com/4212806/180578039-ce315b8a-6678-4f25-aa8e-e35e4a5e63dc.jpg -O images/image_2.jpg
wget https://user-images.githubusercontent.com/4212806/180578040-f1d34f29-ce3f-4fc8-9e58-1d009df84959.jpg -O images/image_3.jpg
wget https://user-images.githubusercontent.com/4212806/180578041-25919c7b-f520-4782-8351-fc8de9ffd016.jpg -O images/image_4.jpg